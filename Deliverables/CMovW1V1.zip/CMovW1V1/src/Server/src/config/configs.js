module.exports = {
  FORCE_UPDATE_DB: false,
};
