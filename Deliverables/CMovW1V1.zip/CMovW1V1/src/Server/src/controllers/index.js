const transactionsController = require('./transactions');
const usersController = require('./users');
const vouchersController = require('./vouchers');

module.exports = {
  transactionsController,
  usersController,
  vouchersController,
};
