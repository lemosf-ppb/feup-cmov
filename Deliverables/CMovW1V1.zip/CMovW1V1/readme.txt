Group elements:

Diogo Luis Rey Torres - 201506428 - up201506428@fe.up.pt
Filipe Oliveira e Sousa Ferreira de Lemos - 201200689 - ee12140@fe.up.pt


Setup Project
It’s assumed that the Android Studio is already installed. The apks of the android application wasn’t generated because the server ip address changes in the local computer(because it’s tested locally and the server wasn’t deployed).

7.2.1. Installing Docker and Docker Compose
Before starting you'll need to have Docker and Docker Compose installed on your PC. 

7.2.2. Configured containers
To start the environment :
$ docker-compose up

    Note: To interact with the containers see docker-compose.yml and what ports are exposed.

7.2.3. Use Android Applications

    Before running the projects it’s necessary to change the server IP in the Customer and Terminal Application, to do that follow the next steps:
Go to AcmeSupermarket/app/src/main/java/services/repository/Constants.java
And changes the ACME_REPOSITORY_URL to your local IP.
Go to TerminalApp/app/src/main/java/com/example/terminalapp/Constants.java
And changes the ACME_REPOSITORY_URL to your local IP.
Note: the android devices need to be connected to the same network as the server.

    Run the projects in the android studio. 

