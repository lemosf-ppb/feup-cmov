﻿namespace WeatherApp
{
    public static class Constants
    {
        public static string OpenWeatherMapForecastEndpoint = "https://api.openweathermap.org/data/2.5/forecast";
        public static string OpenWeatherMapWeatherEndpoint = "https://api.openweathermap.org/data/2.5/weather";
        public static string OpenWeatherMapApiKey = "9c9527823d0d06d5fac5e11d5865d56f";
    }
}