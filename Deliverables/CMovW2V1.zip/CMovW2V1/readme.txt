Group elements:

Diogo Luis Rey Torres - 201506428 - up201506428@fe.up.pt
Filipe Oliveira e Sousa Ferreira de Lemos - 201200689 - ee12140@fe.up.pt