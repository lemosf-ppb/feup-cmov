package utils;

public class Constants {

    public static final String ACTION_SCAN = "com.google.zxing.client.android.SCAN";
    public static final String QR_READER_PLAYSTORE = "market://search?q=pname:com.google.zxing.client.android";
    public static int tagId = 0x41636D65;        // equal to "Acme"
}
